# Beautiful Curves for your Website

Examples of creating backgrounds that use curves, waves, and blobs on a webpage. 

Watch the full [Wavy Blobby Backgrounds with CSS and SVG Tutorial](https://youtu.be/lPJVi797Uy0) video.

## Run it

```
git clone <this-repo>
npx serve
```

